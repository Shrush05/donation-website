const mongoose = require("mongoose");

const donSchema = new mongoose.Schema({
  fnam: {
    type: String,
    required: true,
    unique: true,
  },
  lnam: {
    type: String,
    required: true,
    unique: true,
  },
  addr: {
    type: String,
    required: true,
  },
  addr2: {
    type: String,
    required: false,
  },
  city: {
    type: String,
    required: true,
  },
  zip: {
    type: String,
    required: true,
  },
  DonateFor: {
    type: String,
    require: true,
  },
  payment: {
    type: String,
    require: true,
  },
  pname: {
    type: String,
    require: true,
    unique: true,
  },
  cardn: {
    type: String,
    require: true,
    unique: true,
  },
  cvv: {
    type: String,
    unique: true,
    require: true,
  },
  date: {
    type: String,
    require: true,
  },
});

const Donate = new mongoose.model("Donate", donSchema);
module.exports = Donate;
