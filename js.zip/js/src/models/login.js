const mongoose = require("mongoose");

const logSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  mail: {
    type: String,
    required: true,
    unique: true,
  },
  pas: {
    type: String,
    required: true,
  },
});

const Login = new mongoose.model("Login", logSchema);
module.exports = Login;
